

%% gama_xeff-gama
clc
clear

figure1 = figure('color',[1 1 1]);
axes1 = axes('Parent',figure1,'XScale','log','YScale','log');%
box(axes1,'on');
hold(axes1,'on');

a=1;
s=1;
d=0.2;
lamd=0:0.001:150;
smc=a*s./(lamd.^(1/2)-d^(1/2)).^2;
% figure(9)
hold on
plot(lamd(1:100),smc(1:100))
hold on
plot(lamd(101:end),smc(101:end))
% hold on
% xx1=[0.001 0.001 d d];
% yy1=[1 0.001 0.001 1];
% patch(xx1,yy1,'k','edgecolor','none','facealpha',1);

axis([0.00103796 125.051 0.00140516 14424.2]);


%% p_beta-gama
gama = 1;

%% A8
hold on
load A8outgoing6.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'pg')

hold on
load A8outgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'pb')

gama = 0.5;
hold on
load A8doutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'pr')

gama = 2;
hold on
load A8ddoutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'pc')

%% A11
gama = 1;
hold on
load A11outgoing6.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'sg')

hold on
load A11outgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'sb')

hold on
gama = 0.5;
load A11doutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'sr')

hold on
gama = 2;
load A11ddoutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'sc')

%% A40
gama = 1;
hold on
load A40outgoing6.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'og')

hold on
load A40outgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'ob')

hold on
gama = 0.5;
load A40doutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'or')

hold on
gama = 2;
load A40ddoutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'oc')

%% A46
gama = 1;
hold on
load A46outgoing6.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'dg')

hold on
load A46outgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'db')

hold on
gama = 0.5;
load A46doutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'dr')

hold on
gama = 2;
load A46ddoutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if ds < 0.00103796 
    ds = 0.00103796;
end
plot(lamd,ds,'dc')


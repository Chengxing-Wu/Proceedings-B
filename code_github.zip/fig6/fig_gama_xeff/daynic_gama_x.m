

%% gama_xeff-gama
clc
clear

figure1 = figure('color',[1 1 1]);
axes1 = axes('Parent',figure1,'XScale','log','YScale','log');%
box(axes1,'on');
hold(axes1,'on');

a=1;
s=1;
d=0.2;
lamd=0:0.001:150;
xc=((d*lamd).^(1/2)-d)./s;
% figure(9)
hold on
plot(lamd(1:100),xc(1:100))
hold on
plot(lamd(101:end),xc(101:end))
% hold on
% xx1=[0.001 0.001 d d];
% yy1=[1 0.001 0.001 1];
% patch(xx1,yy1,'k','edgecolor','none','facealpha',1);

axis([0.00409245 123.395 0.0031232 31.0771]);


%% p_beta-gama
gama = 1;

%% A8
hold on
load A8outgoing6.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'pg')

hold on
load A8outgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'pg')

hold on
gama = 0.5;
load A8doutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'pg')

hold on
gama = 2;
load A8ddoutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'pg')

%% A11
hold on
gama = 1;
load A11outgoing6.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'sb')

hold on
load A11outgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'sb')

hold on
gama = 0.5;
load A11doutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'sb')

hold on
gama = 2;
load A11ddoutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'sb')
%% A40
hold on
gama = 1;
load A40outgoing6.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'or')

hold on
load A40outgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'or')

hold on
gama = 0.5;
load A40doutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'or')

hold on
gama = 2;
load A40ddoutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'or')
%% A46
hold on
gama = 1;
load A46outgoing6.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'dy')

hold on
load A46outgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'dy')

hold on
gama = 0.5;
load A46doutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'dy')

hold on
gama = 2;
load A46ddoutgoing8.mat
lamd = (1-plnn)*gama-plnn*gama;
if dx < 0.0031232 
    dx = 0.0031232;
end
plot(lamd,dx,'dy')




%% p_beta-gama
clc
clear

figure1 = figure('color',[1 1 1]);
axes1 = axes('Parent',figure1,'YScale','log');%
box(axes1,'on');
hold(axes1,'on');

a=1;
s=1;
d=0.2;
r1 = 1;
r2 = 1;
p = 0:0.001:1;
for steppp = 1 : length(p)
    lamd=(1-p(steppp))*r1-p(steppp)*r2;
%     xc(steppp)=((d*lamd)^(1/2)-d)/s;
%     xc(steppp)=((d*lamd).^(1/2)-d)./s;
    smc(steppp)=a*s./(lamd.^(1/2)-d^(1/2)).^2;
end

plot(p,smc)


%% A8
hold on
load A8outgoing6.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'pg')

hold on
load A8outgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'pg')

hold on
load A8doutgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'pg')

hold on
load A8ddoutgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'pg')
%% A11
hold on
load A11outgoing6.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'sb')

hold on
load A11outgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'sb')

hold on
load A11doutgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'sb')

hold on
load A11ddoutgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'sb')
%% A40
hold on
load A40outgoing6.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'or')

hold on
load A40outgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'or')

hold on
load A40doutgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'or')

hold on
load A40ddoutgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'or')
%% A46
hold on
load A46outgoing6.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'dy')

hold on
load A46outgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'dy')

hold on
load A46doutgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'dy')

hold on
load A46ddoutgoing8.mat
if dx < 0.00294227 
    dx = 0.00294227;
end
plot(plnn,ds,'dy')

axis([0.0 0.7 0.0037 34945.9]);



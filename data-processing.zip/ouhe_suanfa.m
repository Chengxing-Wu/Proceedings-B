clear
for bilu = 0:0.1:1  %��ռ����
    
load mpl56.mat
A = MPL056;
[m,n] = size(A);

  for im = 1:m         %��
      for jm = im+1:m
          countim = 0;
          countjm = 0;
          count = 0;   
          for t = 1:n
              if A(im,t) > 0
                  A(im,t) = 1;
                  countim = countim + 1;%im���ж�������
              else
                  A(im,t) = 0;
              end
              if A(jm,t) >0
                  A(jm,t) = 1;
                  countjm = countjm + 1;%jm�ж�������
              else
                  A(jm,t) = 0;
              end
              if A(im,t) == A(jm,t) && A(jm,t) > 0 && A(im,t) > 0
                     count = count + 1;
              end
          end
          
          if count/countim >= bilu && count/countjm >= bilu
                 A(im,n+jm) = -1;A(jm,n+im) = -1;
          else
                  A(im,n+jm) = 0;A(jm,n+im) = 0;
          end
      end
  end
    
  for in = 1:n       %��
      for jn = in+1:n
          countin = 0;
          countjn = 0;
          count = 0;
          for t =1:m
              if A(t,in) > 0
                  A(t,in) = 1;
                  countin = countin + 1; 
              else
                  A(t,in) = 0;
              end
              if A(t,jn) > 0
                  A(t,jn) = 1;
                  countjn = countjn + 1;
              else
                  A(t,jn) = 0;
              end
              if A(t,in) == A(t,jn) && A(t,jn) > 0 && A(t,in) > 0 
                     count = count + 1;
              end
            end
            if count/countin >= bilu && count/countjn >= bilu
                 A(m+in,jn) = -1;A(m+jn,in) = -1;
                 else
                  A(m+in,jn) = 0;A(m+jn,in) = 0;
            end
          end
      end
    
  for in = 1:m
      for jn = 1:n
          A(m+jn,n+in) = A(in,jn);
      end
  end      %������ϵ�ԽǾ���
%��־���
AA=A(1:m,:);
BB=A(m+1:m+n,:);
A=[BB;AA];
%����
filename   =  strcat('M56R0',   num2str(bilu*10),  '.mat');
save(filename,    'A','m','n'); 
end

clc
clear
load M24_03.mat

%  A = ouhe_ER(8,50,1);
A = A';
count = 0;p = 0;
[i,j,s] = find(A);
for stepps = 1:length(i)
    if s(stepps) < 0
        count = count + 1;
        p = p + 1;
    else if s(stepps) > 0
        p = p+1;
        end
    end
end
plnn = count/p;
%---Parameters for iteration_synthetic_R-----------
t0 = 0; % the start time 
tf = 200; % the end time 
x_low = 0;
x_high = 5;
n_A = length(A);
%---Parameters for iteration_synthetic_R-----------
%% calculate the low state
x0 = ones(n_A,1)*x_low;  % Initial conditions
options = [];
[t,x] = ode45(@M_system,[t0,tf],x0,options,A); 
xl_ss = x(end,:);
xl_ss = xl_ss'; 
%% calculate the high state
x0 = ones(n_A,1)*x_high;  % Initial conditions
options = [];
[t,x] = ode45(@M_system,[t0,tf],x0,options,A); 
xh_ss = x(end,:); 
xh_ss = xh_ss';
%% calculate the results
[xl_nn,beta] = betaspace(A,xl_ss);
[xh_nn,beta] = betaspace(A,xh_ss);
%%---���� �� �� xeff -----------
beta0(1,1) = beta;
xnn(1,1) = xl_nn;
xnn(2,1) = xh_nn;      
% figure1 = figure('color',[1 1 1]);
% axes1 = axes('Parent',figure1,'XScale','log','YScale','log');%
% box(axes1,'on');
% hold(axes1,'on');
%��ʼ��'FontSize',24,

b = 0.1; c = 1; k = 5; d = 5;e = 0.9; h = 0.1; f = 1;% p = 0.2167;
x=0:0.02:30;
func=-(b+x.*(1-x./k).*(x./c-1)).*1./(-plnn./(1+f.*x)+(1-plnn)./(d+x.*(e+h)))./(x.*x);
lg(1) = plot(func,x,'-k','LineWidth',1);
hold on

xlim([0.09 20]);
ylim([0.08 11]);
% set(gca,'xtick',[10^-1 10^0 10^1 10^2],'XTickLabel',{'10^-^1','10^0','10^1'})
% set(gca,'ytick',[10^-1 10^0 10^1 10^2],'YTickLabel',{'10^-^1','10^0','10^1'})
set(gca,'FontSize',20);
% ����ֵ
lg(4:5) = plot(beta,xnn,'ob');


function Fv = M_system(~,x,A)
%   M_system describes the mutualistic dynamic
%   Fv = M_system(t,x,A)
%---Parameters for mutualistic���� dynamics-----------
K = 5; AA = 1; D = 5; E = 0.9; H =0.1;F = 1;

%---Parameters for mutualistic dynamics-----------
[i,j,s] = find(A);

A0=A.^2;%ƽ������
Af=(A0-A)/2;%������
Az=A0-Af;%������

ssxi = [];
%---Parameters for mutualistic dynamics-----------
% [i,j,sf] = find(Af);
% [i,j,sz] = find(Az);
% [i,j,s] = find(A);
% The Alle efect self dynamic
Fv = (0.1-x.*(x/K-1).*(x/AA-1)); 
% the interaction term
for steps = 1:length(i)
    if  s(steps) > 0
    Fv(i(steps)) = Fv(i(steps))+s(steps)*x(i(steps))*x(j(steps))/(D+E*x(i(steps)) +H*x(j(steps)) );
     ssxi(steps) = x(i(steps));
    else if s(steps) < 0
     Fv(i(steps)) = Fv(i(steps))+s(steps)*x(i(steps))*x(j(steps))/(1+ F*x(j(steps)));
     ssxi(steps) = x(i(steps));
        end
    end
end

save sss.mat ssxi
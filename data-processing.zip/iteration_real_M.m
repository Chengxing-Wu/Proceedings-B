function [beta0,xnn,plnn,xi]= iteration_real_M(steps,A,beta0,xnn,plnn,xi)

n = length(A); % number of nodes in the network
A = A';
%---Parameters for iteration_synthetic_R-----------
t0 = 0; % the start time 
tf = 200; % the end time 
x_low = 0;
x_high = 5;
%---Parameters for iteration_synthetic_R-----------

%% calculate the low state
x0 = ones(n,1)*x_low;  % Initial conditions
options = [];
[t,x] = ode45(@M_system,[t0,tf],x0,options,A); 
xl_ss = x(end,:);

%��xi
xi(1,steps) = xl_ss(1,n);

xl_ss = xl_ss'; 
   
%% calculate the high state
x0 = ones(n,1)*x_high;  % Initial conditions
options = [];
[t,x] = ode45(@M_system,[t0,tf],x0,options,A); 
xh_ss = x(end,:); 

% %%����Xi����ֵ
xi(2,steps) = xh_ss(1,n);

xh_ss = xh_ss';

%% calculate the results
[xl_nn,beta] = betaspace(A,xl_ss);
[xh_nn,beta] = betaspace(A,xh_ss);

%%---���� �� �� xeff -----------
beta0(1,steps) = beta;
xnn(1,steps) = xl_nn;
xnn(2,steps) = xh_nn;      
      
%%---���� P -----------
count = 0;p = 0;
[i,j,s] = find(A);
for stepps = 1:length(i)
    if s(stepps) < 0
        count = count + 1;
        p = p + 1;
    else if s(stepps) > 0
        p = p+1;
        end
    end
end
plnn(1,steps) = count/p;

